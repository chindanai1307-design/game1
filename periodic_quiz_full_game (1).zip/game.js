const quizData = [
  {q: "ธาตุใดมีสัญลักษณ์ว่า H?", options:["Hydrogen","Helium","Hassium","Holmium"], answer:0},
  {q: "ธาตุใดมีเลขอะตอม 6?", options:["Carbon","Oxygen","Nitrogen","Neon"], answer:0},
  {q: "ธาตุใดมีสัญลักษณ์ว่า Na?", options:["Sodium","Nitrogen","Neptunium","Nickel"], answer:0},
  {q: "ทองคำมีสัญลักษณ์ว่าอะไร?", options:["Ag","Au","Pt","Pb"], answer:1},
  {q: "ธาตุใดเป็นก๊าซเฉื่อย?", options:["Neon","Sodium","Chlorine","Magnesium"], answer:0},
  {q: "ธาตุใดมีเลขอะตอม 1?", options:["Hydrogen","Helium","Lithium","Beryllium"], answer:0},
  {q: "O เป็นสัญลักษณ์ของธาตุใด?", options:["Oxygen","Osmium","Oxalate","Organium"], answer:0},
  {q: "ธาตุใดอยู่ในหมู่ Halogen?", options:["Fluorine","Neon","Calcium","Iron"], answer:0},
  {q: "Fe เป็นสัญลักษณ์ของธาตุใด?", options:["Iron","Fluorine","Francium","Fermium"], answer:0},
  {q: "He เป็นสัญลักษณ์ของธาตุใด?", options:["Helium","Hydrogen","Hafnium","Holmium"], answer:0}
];

let current = 0, score = 0;
const quizEl = document.getElementById("quiz");

function loadQuestion(){
  if(current >= quizData.length){
    quizEl.innerHTML = `<h2>คุณทำได้ ${score} / ${quizData.length} ข้อ</h2>`;
    return;
  }
  const data = quizData[current];
  quizEl.innerHTML = `<div class='question'>${data.q}</div>`;
  const optionsDiv = document.createElement("div");
  optionsDiv.className = "options";
  data.options.forEach((opt,i)=>{
    const btn = document.createElement("button");
    btn.textContent = opt;
    btn.onclick = ()=>{
      if(i===data.answer) score++;
      current++;
      loadQuestion();
    };
    optionsDiv.appendChild(btn);
  });
  quizEl.appendChild(optionsDiv);
}
loadQuestion();